const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('List all of my commands.')
		.setDMPermission(false),
	run: async (client, interaction) => {
		const commands = await client.application.commands.fetch();

		const data = [];
		commands.forEach((element) => {
			data.push(`</${element.name}:${element.id}>`);
		});
		const commandList = data.join('\n');

		const embed = new EmbedBuilder()
			.setColor('#0099ff')
			.setTitle('Command List')
			.setDescription(
				`Here's a list of all my commands:\n\n${commandList}`,
			);

		await interaction.reply({ embeds: [embed] });
	},
};
