const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('ping')
		.setDescription('Shows the bot latency!')
		.setDMPermission(false),
	global: true,
	run: async (client, interaction) => {
		const embed = new EmbedBuilder()
			.setTitle('Calculating ping...')
			.setDescription('This may take some time.')
			.setColor('#2f3136');
		const inter = await interaction.reply({
			embeds: [embed],
			fetchReply: true,
		});

		const ping = interaction.createdTimestamp - inter.createdTimestamp;

		const resultEmbed = new EmbedBuilder()
			.setTitle('🏓Pong!')
			.setDescription(
				`> **Bot** latency: \`${ping}\`ms \n> **API** latency: \`${client.ws.ping}\`ms`,
			)
			.setColor('#2f3136')
			.setFooter({
				text: 'Voided Hosting',
				iconURL: client.user.avatarURL(),
			});
		await interaction.editReply({ embeds: [resultEmbed] });
	},
};
