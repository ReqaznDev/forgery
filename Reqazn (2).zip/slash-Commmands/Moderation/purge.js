const {
	EmbedBuilder,
	SlashCommandBuilder,
	PermissionFlagsBits,
} = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('purge')
		.setDescription('Deletes a specific number of messages.')
		.addNumberOption((option) =>
			option
				.setName('amount')
				.setDescription('Select the number of messages to delete.')
				.setRequired(true)
				.setMinValue(1)
				.setMaxValue(100),
		)
		.setDMPermission(false)
		.setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
	global: true,
	run: async (client, interaction) => {
		const amount = interaction.options.getNumber('amount');

		const logChannelId =
			client.config.logChannel ||
			client.db.get(`${interaction.guild.id}.config.logChannel`) ||
			'926824838134399026';

		const logChannel = await interaction.guild.channels.fetch(logChannelId);

		if (!logChannel) {
			return interaction.editReply({
				content:
					'Log channel not found! Contact the admins to set it up!',
			});
		}

		const successembed = new EmbedBuilder()
			.setColor('#2f3136')
			.setDescription(`**Successfully purged \`${amount}\` messages!**`);

		await interaction.channel.bulkDelete(amount, true);

		const logembed = new EmbedBuilder()
			.setColor('#2f3136')
			.setAuthor({
				name: `${interaction.user.username} (${interaction.user.id})`,
				iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
			})
			.setDescription(
				`**Member:** \`${interaction.user.username}\` (${interaction.user.id}) \n**Used:** \`purge ${amount}\` \n**Channel:** <#${interaction.channel.id}> \n**[Link!](https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id})**`,
			)
			.setTimestamp();
		logChannel.send({ embeds: [logembed] });

		return await interaction.reply({
			embeds: [successembed],
			ephemeral: true,
		});
	},
};
