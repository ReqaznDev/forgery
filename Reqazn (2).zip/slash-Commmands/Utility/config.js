const {
	SlashCommandBuilder,
	EmbedBuilder,
	PermissionsBitField,
	ChannelType,
} = require('discord.js');
const ms = require('ms');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('config')
		.setDescription('config bot?')
		.addSubcommand((subcommand) =>
			subcommand
				.setName('welcome_channel')
				.setDescription('Select the welcome channel')
				.addChannelOption((option) =>
					option
						.setName('channel')
						.setDescription(
							'Set the welcome channel, if unset welcome module will be disabled'
						)
						.setRequired(false)
						.addChannelTypes(ChannelType.GuildText)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('welcome_msg')
				.setDescription('Select the welcome message')
				.addStringOption((option) =>
					option
						.setName('message')
						.setDescription(
							'Set the welcome message, {{guild}} - Guild Name, {{user}} - Username, {{userid}} - User ID'
						)
						.setRequired(true)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('leave_channel')
				.setDescription('Select the leave channel')
				.addChannelOption((option) =>
					option
						.setName('channel')
						.setDescription(
							'Set the leave channel, if unset goodbyes module will be disabled'
						)
						.setRequired(false)
						.addChannelTypes(ChannelType.GuildText)
				)
		)
        .addSubcommand((subcommand) =>
			subcommand
				.setName('leave_msg')
				.setDescription('Select the leave message')
				.addStringOption((option) =>
					option
						.setName('message')
						.setDescription(
							'Set the leave message, {{guild}} - Guild Name, {{user}} - Username, {{userid}} - User ID'
						)
						.setRequired(true)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('memberlog_channel')
				.setDescription('Select the member log channel')
				.addChannelOption((option) =>
					option
						.setName('channel')
						.setDescription(
							'Set the member log channel, if unset member log module will be disabled'
						)
						.setRequired(false)
						.addChannelTypes(ChannelType.GuildText)
				)
		),
	global: true,
	run: async (client, interaction) => {
		const db = client.db;
		if (interaction.options.getSubcommand() === 'welcome_channel') {
			const WlcmChannel = interaction.options.getChannel('channel');

			if (!WlcmChannel) {
				client.db.set(`${interaction.guild.id}.welcome.channel`, false);
				return interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setDescription(
								`${client.emotes.tick} Welcome System disabled.`
							)
							.setColor('Green'),
					],
					ephemeral: true,
				});
			}

			client.db.set(
				`${interaction.guild.id}.welcome.channel`,
				WlcmChannel.id
			);
			interaction.reply({
				embeds: [
					new EmbedBuilder()
						.setDescription(
							`${client.emotes.tick} Welcome channel set to ${WlcmChannel}.`
						)
						.setColor('Green'),
				],
				ephemeral: true,
			});
		} else if (interaction.options.getSubcommand() === 'welcome_msg') {
			const WlcmText = interaction.options.getString('message');

			client.db.set(
				`${interaction.guild.id}.welcome.message`,
				WlcmText
			);

			interaction.reply({
				embeds: [
					new EmbedBuilder()
						.setDescription(
							`${client.emotes.tick} Welcome message set to\n${WlcmText}.`
						)
						.setColor('Green'),
				],
				ephemeral: true,
			});
		} else if (interaction.options.getSubcommand() === 'leave_channel') {
			const LeaveChannel = interaction.options.getChannel('channel');

			if (!LeaveChannel) {
				client.db.set(`${interaction.guild.id}.leave.channel`, false);
				return interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setDescription(
								`${client.emotes.tick} Goodbye System disabled.`
							)
							.setColor('Green'),
					],
					ephemeral: true,
				});
			}

			client.db.set(
				`${interaction.guild.id}.leave.channel`,
				LeaveChannel.id
			);
			interaction.reply({
				embeds: [
					new EmbedBuilder()
						.setDescription(
							`${client.emotes.tick} Leave channel set to ${LeaveChannel}.`
						)
						.setColor('Green'),
				],
				ephemeral: true,
			});
		} else if (interaction.options.getSubcommand() === 'leave_msg') {
			const LeaveText = interaction.options.getString('message');

			client.db.set(
				`${interaction.guild.id}.leave.message`,
				LeaveText
			);

			interaction.reply({
				embeds: [
					new EmbedBuilder()
						.setDescription(
							`${client.emotes.tick} Leave message set to\n${LeaveText}.`
						)
						.setColor('Green'),
				],
				ephemeral: true,
			});
		} else if (
			interaction.options.getSubcommand() === 'memberlog_channel'
		) {
			const MemLogChannel = interaction.options.getChannel('channel');

			if (!MemLogChannel) {
				client.db.set(
					`${interaction.guild.id}.memberlog.channel`,
					false
				);
				return interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setDescription(
								`${client.emotes.tick} Member Logging System disabled.`
							)
							.setColor('Green'),
					],
					ephemeral: true,
				});
			}

			client.db.set(
				`${interaction.guild.id}.memberlog.channel`,
				MemLogChannel.id
			);
			interaction.reply({
				embeds: [
					new EmbedBuilder()
						.setDescription(
							`${client.emotes.tick} Member Log channel set to ${MemLogChannel}.`
						)
						.setColor('Green'),
				],
				ephemeral: true,
			});
		}
	},
};
