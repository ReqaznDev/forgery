const {
	EmbedBuilder,
	SlashCommandBuilder,
	PermissionFlagsBits,
} = require('discord.js');
const status = require('../../status.json');
const fs = require('fs');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('status')
		.setDescription('Change the bot status')
		.setDMPermission(false)
		.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
		.addStringOption((option) =>
			option
				.setName('text')
				.setDescription('State what you want in the status')
				.setRequired(true),
		),
	global: true,
	run: async (client, interaction) => {
		const text = interaction.options.getString('text');

		client.user.setActivity(text, {
			type: 'STREAMING',
			url: 'https://www.twitch.tv/ReqaznTheDev',
		});

		const successEmbed = new EmbedBuilder()
			.setColor('#2F3136')
			.setTitle('__Success!__')
			.setDescription(
				`My __status__ has been successfully changed to: \n**${text}**`,
			)
			.setFooter({
				text: `by ${client.user.username}`,
				iconURL: client.user.avatarURL(),
			});

		interaction.reply({ embeds: [successEmbed] });
		status.status = text;
		fs.writeFile(
			'./status.json',
			JSON.stringify(status, null, 4),
			'utf8',
			(err) => {
				if (err) throw err;
			},
		);
	},
};
