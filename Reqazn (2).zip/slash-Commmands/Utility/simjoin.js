const { SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('simjoin')
		.setDescription('Simulates a user joning!')
		.setDMPermission(false),
	category: 'utility',
	global: true,
	run: (client, message) => {
		client.emit('guildMemberAdd', message.member);
	},
};
