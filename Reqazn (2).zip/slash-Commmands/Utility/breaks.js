const {
	SlashCommandBuilder,
	EmbedBuilder,
	PermissionsBitField,
	ChannelType,
} = require('discord.js');
const ms = require('ms');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('break')
		.setDescription('Add/Remove a User on Break')
		.addSubcommand((subcommand) =>
			subcommand
				.setName('add')
				.setDescription('Add a user to break.')
				.addUserOption((option) =>
					option
						.setName('user')
						.setDescription(
							'The user who you want to add to break.'
						)
						.setRequired(true)
				)
				.addStringOption((option) =>
					option
						.setName('time')
						.setDescription(
							'Set how long you want the user to be on break.'
						)
						.setRequired(true)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('remove')
				.setDescription('Remove a user from break.')
				.addUserOption((option) =>
					option
						.setName('user')
						.setDescription(
							'The user who you want to remove from break.'
						)
						.setRequired(true)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('decline')
				.setDescription('Decline a Break Request.')
				.addUserOption((option) =>
					option
						.setName('user')
						.setDescription(
							'The user who you want to decline the break from.'
						)
						.setRequired(true)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('request')
				.setDescription('Request For a break.')
				.addStringOption((option) =>
					option
						.setName('reason')
						.setDescription('The reason for the break.')
						.setRequired(true)
				)
				.addStringOption((option) =>
					option
						.setName('time')
						.setDescription('The time length for the break.')
						.setRequired(true)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('channel')
				.setDescription('Select the break request channel')
				.addChannelOption((option) =>
					option
						.setName('channel')
						.setDescription(
							'Set the break request channel, if unset break module will be disabled'
						)
						.setRequired(false)
						.addChannelTypes(ChannelType.GuildText)
				)
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName('role')
				.setDescription('Select the break role')
				.addRoleOption((option) =>
					option
						.setName('role')
						.setDescription(
							'Set the break role, if unset break module will be disabled'
						)
						.setRequired(false)
				)
		),
	global: true,
	run: async (client, interaction) => {
		const db = client.db;
		switch (interaction.options.getSubcommand()) {
			case 'channel':
				const breakChannel = interaction.options.getChannel('channel');

				if (!breakChannel) {
					client.db.set(
						`${interaction.guild.id}.break.channel`,
						false
					);
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.tick} Break System disabled.`
								)
								.setColor('Green'),
						],
						ephemeral: true,
					});
				}

				client.db.set(
					`${interaction.guild.id}.break.channel`,
					breakChannel.id
				);
				interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setDescription(
								`${client.emotes.tick} Break Request channel set to ${breakChannel}.`
							)
							.setColor('Green'),
					],
					ephemeral: true,
				});
				break;
			case 'role':
				const breakRole = interaction.options.getRole('role');

				if (!breakRole) {
					client.db.set(`${interaction.guild.id}.break.role`, false);
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.tick} Break System disabled.`
								)
								.setColor('Green'),
						],
						ephemeral: true,
					});
				}

				client.db.set(
					`${interaction.guild.id}.break.role`,
					breakRole.id
				);
				interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setDescription(
								`${client.emotes.tick} Break Role set to ${breakRole}.`
							)
							.setColor('Green'),
					],
					ephemeral: true,
				});
				break;
			case 'decline':
				if (
					!interaction.member.permissions.has(
						PermissionsBitField.Flags.ManageGuild
					)
				) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} You are not allowed to add user's to breaks. [You need \`MANAGE_GUILD\`]`
								)
								.setColor('Red'),
						],
					});
				}

				let dmember = await interaction.options.getMember('user');

				if (!dmember) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Invalid member / Member not found`
								)
								.setColor('Red'),
						],
					});
				}

				if (dmember.user.bot) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Try it on a human next time`
								)
								.setColor('Red'),
						],
					});
				}

				dmember
					.send({
						content:
							'Your Break Have Been Declined, Please Try again later',
					})
					.then((x) => {
						interaction.reply({
							embeds: [
								new EmbedBuilder()
									.setDescription(
										`${client.emotes.tick} Successfully DMed The user!`
									)
									.setColor('Green'),
							],
						});
					})
					.catch((x) => {
						interaction.reply({
							embeds: [
								new EmbedBuilder()
									.setDescription(
										`${client.emotes.cross} User's DM's are Disabled!`
									)
									.setColor('Red'),
							],
						});
					});
				break;
			case 'request':
				const rdata = client.db.get(
					`${interaction.guild.id}.break.channel`
				);
				const rdata2 = client.db.get(
					`${interaction.guild.id}.break.role`
				);

				if (!rdata || !rdata2) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Break System disabled`
								)
								.setColor('Red'),
						],
					});
				}

				interaction.reply({
					content:
						'You have requested for a break successfully, please wait while its being reviewed',
					ephemeral: true,
				});
				let embed = new EmbedBuilder()
					.setTitle(`New Break Request!`)
					.setAuthor({
						name: interaction.user.username,
						iconURL: interaction.user.displayAvatarURL({
							dynamic: true,
						}),
					})
					.setDescription(
						`**Reason**:\n\n` +
							interaction.options.getString('reason')
					)

					.addFields([
						{
							name: 'Time Length',
							value: interaction.options.getString('time'),
						},
					])
					.setColor('Blurple')
					.setFooter({
						text: `Use [/break add <options>] to accept this request`,
					})
					.setTimestamp();

				const rchannel = await interaction.guild.channels.fetch(rdata);

				rchannel.send({
					embeds: [embed],
				});
				break;
			case 'add':
				if (
					!interaction.member.permissions.has(
						PermissionsBitField.Flags.ManageGuild
					)
				) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} You are not allowed to add user's to breaks. [You need \`MANAGE_GUILD\`]`
								)
								.setColor('Red'),
						],
					});
				}

				const adata = client.db.get(
					`${interaction.guild.id}.break.channel`
				);
				const adata2 = client.db.get(
					`${interaction.guild.id}.break.role`
				);

				if (!adata || !adata2) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Break System disabled`
								)
								.setColor('Red'),
						],
					});
				}

				let amember = await interaction.options.getMember('user');

				if (!amember) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Invalid member / Member not found`
								)
								.setColor('Red'),
						],
					});
				}

				if (amember.user.bot) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Try it on a human next time`
								)
								.setColor('Red'),
						],
					});
				}

				if (db.has(`breaks.${amember.id}`)) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} User is already on break.`
								)
								.setColor('Red'),
						],
					});
				}

				let Breakrole = interaction.guild.roles.cache.find(
					(r) => r.id == adata2
				);
				if (!Breakrole)
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} couldn't find the Break role`
								)
								.setColor('Red'),
						],
					});

				let time = interaction.options
					.getString('time')
					.replaceAll(' ', '');

				if (!time) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Please enter a Time.`
								)
								.setColor('Red'),
						],
					});
				}

				if (!finate(time))
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Provide proper time. ex \`3days - for 3 Days..\``
								)
								.setColor('Red'),
						],
					});

				client.db.set(`breaks.${amember.id}`, {
					guild: interaction.guild.id,
					time: Date.now() + finate(time),
				});

				await amember.roles
					.add(Breakrole)
					.catch((err) =>
						console.error(
							`Couldn't Add Role to User on server\nUser: ${amember.id}\n--------------------------\n${err}`
						)
					);

				await interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setDescription(
								`${client.emotes.tick} You have put **${
									amember.user.username
								}** For ${ms(finate(time), {
									long: true,
								})}`
							)
							.setColor('Green'),
					],
				});

				amember
					.send({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${
										client.emotes.tick
									} You are now in break break For ${ms(
										finate(time),
										{
											long: true,
										}
									)}`
								)
								.setColor('Green'),
						],
					})
					.catch((err) =>
						console.log(
							`Users DMS Are Closed\n${amember.id}\n--------------------------\n${err}`
						)
					);
				break;

			case 'remove':
				if (
					!interaction.member.permissions.has(
						PermissionsBitField.Flags.ManageGuild
					)
				) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} You are not allowed to remove user's to breaks. [You need \`MANAGE_GUILD\`]`
								)
								.setColor('Red'),
						],
					});
				}

				const rrdata = client.db.get(
					`${interaction.guild.id}.break.channel`
				);
				const rrdata2 = client.db.get(
					`${interaction.guild.id}.break.role`
				);

				if (!rrdata || !rrdata2) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Break System disabled`
								)
								.setColor('Red'),
						],
					});
				}

				let rrmember = await interaction.options.getMember('user');

				if (!rrmember) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Invalid member / Member not found`
								)
								.setColor('Red'),
						],
					});
				}

				if (rrmember.user.bot) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} Try it on a human next time`
								)
								.setColor('Red'),
						],
					});
				}
				if (!db.has(`breaks.${rrmember.id}`)) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} User isn't on break.`
								)
								.setColor('Red'),
						],
					});
				}

				let Breakrole2 = interaction.guild.roles.cache.find(
					(r) => r.id == rrdata2
				);
				if (!Breakrole2)
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.cross} couldn't find the Break role`
								)
								.setColor('Red'),
						],
					});

				client.db.delete(`breaks.${rrmember.id}`);

				rrmember.roles
					.remove(Breakrole2)
					.catch((err) =>
						console.error(
							`Couldn't Remove Role to User on server\nUser: ${rrmember.id}\n--------------------------\n${err}`
						)
					);

				await interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setDescription(
								`${client.emotes.tick} You removed **${rrmember.user.username}** from break.`
							)
							.setColor('Green'),
					],
				});
				rrmember
					.send({
						embeds: [
							new EmbedBuilder()
								.setDescription(
									`${client.emotes.tick} You were removed from your break`
								)
								.setColor('Green'),
						],
					})
					.catch((err) =>
						console.log(
							`Users DMS Are Closed\nUser: ${rrmember.id}\n--------------------------\n${err}`
						)
					);

				break;
		}
	},
};

function finate(value) {
	return ms(value);
}
