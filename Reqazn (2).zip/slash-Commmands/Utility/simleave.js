const { SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('simleave')
		.setDescription('Simulates a user leaving!')
		.setDMPermission(false),
	category: 'utility',
	global: true,
	run: (client, message) => {
		client.emit('guildMemberRemove', message.member);
	},
};
