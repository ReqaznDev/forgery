const {
	ActionRowBuilder,
	SelectMenuBuilder,
	EmbedBuilder,
} = require('discord.js');

module.exports = {
	name: 'ddroles',
	cooldown: 2,
	userPermissions: ['ManageGuild'],
	aliases: ['ddr'],
	category: 'Utility',
	description: 'Set dropdown reaction roles.',

	run: async (client, message) => {
		const roleEmbed = new EmbedBuilder()
			.setColor('#4f47ff')
			.setTitle('✰ 𓂃 ៸៸ NOTIFICATION PINGS . . .')
			.setDescription(
				'Choose your pings from the dropdown below!\nSimply click the role you would like to have vice-versa to remove.',
			)
			.setFooter({
				text: `by ${message.guild.name}`,
				iconURL: message.guild.iconURL(),
			});

		const row = new ActionRowBuilder().addComponents(
			new SelectMenuBuilder()
				.setCustomId('pingroles')
				.setPlaceholder('Select To Add/Remove Roles!')
				.addOptions([
					{
						label: 'Voided Host Updates',
						description:
							'Click to recieve the Voided Host Updates role!',
						value: 'voided',
					},
					{
						label: 'Maintenance',
						description: 'Click to recieve the Maintenance role!',
						value: 'maintenance',
					},
					{
						label: 'Status Updates',
						description:
							'Click to recieve the Status Updates role!',
						value: 'status',
					},
					{
						label: 'Giveaways',
						description: 'Click to recieve the Giveaways role!',
						value: 'giveaways',
					},
					{
						label: 'Offers & Sales',
						description: 'Click to recieve the Offers & Sale role!',
						value: 'offers',
					},
					{
						label: 'Bot Updates',
						description: 'Click to recieve the Bot Updates role!',
						value: 'botupdates',
					},
					{
						label: 'Tutorials',
						description: 'Click to recieve the Tutorials role!',
						value: 'tutorials',
					},
					{
						label: 'Announcements',
						description: 'Click to recieve the Announcements role!',
						value: 'announcements',
					},
				]),
		);
		message.channel.send({ embeds: [roleEmbed], components: [row] });
	},
};
