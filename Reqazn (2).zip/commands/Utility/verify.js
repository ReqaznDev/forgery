const {
	EmbedBuilder,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
} = require('discord.js');

module.exports = {
	name: 'verify',
	cooldown: 2,
	userPermissions: ['ManageGuild'],
	aliases: ['ver'],
	category: 'Utility',
	description: 'Set the verification role.',

	run: async (client, message) => {
		const verifyEmbed = new EmbedBuilder()
			.setColor('#4f47ff')
			.setAuthor({ name: 'Voided Hosting', ic: client.user.avatarURL() })
			.setDescription(
				'Press the `Verify` button below to access the rest of the server.',
			);

		const vevebutton = new ActionRowBuilder().addComponents(
			new ButtonBuilder()
				.setCustomId('verifybutton')
				.setLabel('Verify')
				.setStyle(ButtonStyle.Primary)
				.setDisabled(false),
		);

		await message.channel.send({
			embeds: [verifyEmbed],
			components: [vevebutton],
			ephemeral: true,
		});
	},
};
