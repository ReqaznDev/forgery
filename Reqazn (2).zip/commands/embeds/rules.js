const {
	EmbedBuilder,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
} = require('discord.js');

module.exports = {
	name: 'rules',
	userPermissions: ['Administrator'],
	cooldown: 4,
	aliases: ['r'],
	category: 'embeds',
	description: 'Set the rules!',

	run: async (client, message) => {
		const embed = new EmbedBuilder()
			.setTitle('Server Rules')
			.setURL('https://www.VoidedHost.com')
			.setDescription(
				`**1. Be Respectful**
Respect all members of the server. Regardless of your liking towards them.

**2. No Profanity**
No profanity whatsoever may be used on this server.

**3. No Spamming**
Do not repeatedly send messages in a short amount of time.

**4. No NSFW Content**
Do not send any inappropriate material in this server.

**5. No Advertising**
Do not send any advertisements on this server. This includes DM advertising.

**6. No Offensive Names or Profile Pictures**
Do not use any profile picture or username that others may think is inappropriate (this includes impersonation).

**7. No Threats or Discrimination**
Do make threats against any members of this server. This includes DDoS, Dox, Death, or any other type of threat. Members are also not allowed to discriminate other members. This includes being racist, sexist, and homophobic.

**8. Mentioning and DMing**
Do not ping or DM members or staff unless they have allowed you to or its important.

**9. Punishment Evasion**
The evasion of punishments in ways such as creating a new account or changing your IP will lead to your punishment being extended.

**10. Discord TOS and Community guidelines**
Follow Discord's TOS and Community Guidelines. They can be found below.
https://discord.com/terms - https://discord.com/guidelines

**11. Pinging Employee's**
--> Pinging our Employee's isn't tolerated, You'll be warned if so. If you don't learn, You'll be removed from the server

**12. Language**
--> Watch your language within all Channels `,
			)
			.setColor('#2f3136')
			.setFooter({
				text: 'by Voided Hosting ©2022',
				iconURL: client.user.avatarURL(),
			});

		const votebutton = new ActionRowBuilder().addComponents(
			new ButtonBuilder()
				.setLabel('Our Website')
				.setStyle(ButtonStyle.Link)
				.setURL('https://www.VoidedHost.com'),
		);
		message.reply({
			embeds: [embed],
			components: [votebutton],
		});
	},
};
