const {
	EmbedBuilder,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
} = require('discord.js');

module.exports = {
	name: 'faq',
	userPermissions: ['Administrator'],
	cooldown: 4,
	aliases: ['faqs'],
	category: 'embeds',
	description: 'Set the faq!',

	run: async (client, message) => {
		const emoji = message.guild.emojis.cache.first();
		console.log(emoji);
		console.log(emoji.toString());
		message.channel.send(`Hello! ${emoji}`);
		const embed = new EmbedBuilder()
			.setTitle('FAQ')
			.setURL('https://www.VoidedHost.com')
			.setDescription(
				`The most FAQ we get asked

**__How do I purchase I Service?__**
Open a sales Ticket! <#1035290562351333448>  or through the website

**__What Payment methods do you accept?__**
PayPal & cash app ( stripe coming soon )

**__Where would i check for your hours__**
You would go to <#1036989774554210314> 

**__Do we do VC/Phone support__**
Yes we do

**__How do I Suggest something__**
You would go to <#994437989398749275>  and do /suggest ( suggestion )

**__Where Can I find your Prices?__**
https://www.VoidedHost.com or make a sales ticket

**__What Do you all sell?__**
Discord Bot Hosting
VPS's
Web Hosting
GTA-V hosting
Gmod Hosting
Minecraft hosting
Voice servers ( all are these are coming soon ) `,
			)
			.setColor('#2f3136')
			.setFooter({
				text: 'by Voided Hosting ©2022',
				iconURL: client.user.avatarURL(),
			});

		const votebutton = new ActionRowBuilder().addComponents(
			new ButtonBuilder()
				.setLabel('Our Website')
				.setStyle(ButtonStyle.Link)
				.setURL('https://www.VoidedHost.com'),
		);
		message.reply({
			embeds: [embed],
			components: [votebutton],
		});
	},
};
