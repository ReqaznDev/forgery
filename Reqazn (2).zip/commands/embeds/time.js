const {
	EmbedBuilder,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
} = require('discord.js');

module.exports = {
	name: 'time',
	userPermissions: ['Administrator'],
	cooldown: 4,
	aliases: ['times'],
	category: 'embeds',
	description: 'Set the ours!',

	run: async (client, message) => {
		const embed = new EmbedBuilder()
			.setTitle('Our Hours!')
			.setURL(
				'https://ptb.discord.com/channels/994437987347734589/994437988748644372',
			)
			.setDescription(
				`<:I_Join:1037423990706290790> Hours of Operation For Support Services
--------------------------------------------------------------
( <:correct:1037826497551024128>  | Open ) Support Tickets | 24/7 
( <:x_:1037826526781132861>  | Close) | Voided Host VC | 5:00pm -  9:00pm ( EST ) 
( <:correct:1037826497551024128>  | Open ) | Voided Host Management | 2:50pm - 9:00pm ( EST ) 
( <:correct:1037826497551024128>  | Open ) | Sales / Billing Office | 8:30am - 9:00pm ( EST )`,
			)
			.setColor('#2f3136')
			.setFooter({
				text: 'by Voided Hosting ©2022',
				iconURL: client.user.avatarURL(),
			});

		const votebutton = new ActionRowBuilder().addComponents(
			new ButtonBuilder()
				.setURL(
					'https://discord.com/channels/994437987347734589/994437988748644372',
				)
				.setLabel('Our Rules!')
				.setStyle(ButtonStyle.Link),
		);
		message.reply({
			embeds: [embed],
			components: [votebutton],
		});
	},
};
