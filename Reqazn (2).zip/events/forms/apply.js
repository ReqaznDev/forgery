const { Events, EmbedBuilder } = require('discord.js');
module.exports = {
	name: Events.InteractionCreate,
	once: false,
	async execute(interaction, client) {
		if (!interaction.isModalSubmit()) return;
		if (interaction.customId.startsWith('apply')) {
			let formName = interaction.customId.split(/-/g)[1];
			const ff = interaction.fields.fields;
			let data = client.db
				.get(`forms`)
				.filter((x) => x.name == formName)[0];
			const embed = new EmbedBuilder()
				.setTitle(`New Response for **${formName}** form.`)
				.setColor('Blurple')
				.setAuthor({
					name: interaction.user.username,
					iconURL: interaction.user.avatarURL(),
				})
				.addFields(
					{
						name: `User ID`,
						value: `${interaction.user.id}`,
					},
					{
						name: `Username`,
						value: `${interaction.user.username}`,
					}
				);

			ff.forEach((element) => {
				if (element.value && element.value.length > 0) {
					embed.addFields({
						name: `${
							data.questions[element.customId.split(/-/g)[1]]
						}`,
						value: `${element.value}`,
					});
				}
			});

			await interaction.reply({
				embeds: [
					new EmbedBuilder()
						.setDescription(`${client.emotes.tick} Sent Form.`)
						.setColor('Green'),
				],
			});

			let chnl = await interaction.guild.channels.fetch(data.channel);

			chnl.send({
				embeds: [embed],
			});
		}
	},
};
