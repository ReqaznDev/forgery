const { Events, EmbedBuilder } = require('discord.js');
module.exports = {
	name: Events.InteractionCreate,
	once: false,
	async execute(interaction, client) {
		if (!interaction.isModalSubmit()) return;
		if (interaction.customId.startsWith('forms')) {
			let formName = interaction.customId.split(/-/g)[1];
			let channel = client.db.get(`frms.${formName}`);
			const ff = interaction.fields.fields;
			const questions = [];
			const embed = new EmbedBuilder()
				.setDescription(
					`${client.emotes.tick} Created new form, **${formName}**`
				)
				.addFields({ name: 'Channel:', value: `<#${channel}>` })
				.setColor('Green');

			ff.forEach((element) => {
				if (element.value && element.value.length > 0) {
					questions.push(element.value);
					embed.addFields({
						name: `Question **${questions.length}**`,
						value: `${element.value}`,
					});
				}
			});

			client.db.push(`forms`, {
				name: formName,
				channel: channel,
				questions: questions,
			});

			client.db.delete(`frms.${formName}`);
			await interaction.reply({
				embeds: [embed],
			});

			let chnl = await interaction.guild.channels.fetch(channel);

			chnl.send({
				embeds: [
					new EmbedBuilder()
						.setDescription(
							`${client.emotes.tick} Response for **${formName}** form will be sent here!`
						)
						.setColor('Green'),
				],
			});
		}
	},
};
