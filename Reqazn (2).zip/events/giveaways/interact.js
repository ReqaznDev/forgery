const {
	Events,
	ActionRowBuilder,
	EmbedBuilder,
	ButtonBuilder,
	ButtonStyle,
	time,
	hyperlink,
} = require('discord.js');

module.exports = {
	name: Events.InteractionCreate,
	once: false,
	async execute(interaction, client) {
		try {
			if (!interaction.isButton()) return;

			if (interaction.customId.startsWith('giveaway')) {
				const data = client.db
					.get('giveaways')
					.filter((x) => x.messageId == interaction.message.id);

				if (!data || !data[0] || data[0].ended) {
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setColor('Yellow')
								.setDescription(
									`${client.emotes.warning} Giveaway doesn\'t exist`,
								),
						],
						ephemeral: true,
					});
				}

				const entry = client.db.get(
					`giveaway.${interaction.message.id}.entry`,
				);
				if (entry.includes(interaction.user.id)) {
					client.db.pull(
						`giveaway.${interaction.message.id}.entry`,
						(element) => element == interaction.user.id,
						true,
					);

					const entries = client.db.substr(
						`giveaway.${interaction.message.id}.entered`,
						1,
					);

					const embed = EmbedBuilder.from(
						interaction.message.embeds[0],
					).setFields(
						{
							name: 'Ends',
							value: `${time(
								Math.round(data[0].endTime / 1000),
								'R',
							)}`,
							inline: true,
						},
						{
							name: 'Hosted by',
							value: `<@${data[0].hostedBy}>`,
							inline: true,
						},
					);

					const button = ActionRowBuilder.from(
						interaction.message.components[0],
					).setComponents(
						new ButtonBuilder()
							.setCustomId('giveaway')
							.setEmoji('🎉')
							.setLabel(`Entries - ${entries}`)
							.setStyle(ButtonStyle.Primary),
					);
					interaction.message.edit({
						embeds: [embed],
						components: [button],
					});
					return interaction.reply({
						embeds: [
							new EmbedBuilder()
								.setColor('Red')
								.setDescription(
									`${
										client.emotes.warning
									} You are no longer participating in the ${hyperlink(
										'giveaway',
										data[0].url,
									)}`,
								),
						],
						ephemeral: true,
					});
				}
				client.db.push(
					`giveaway.${interaction.message.id}.entry`,
					interaction.user.id,
				);
				const entries = client.db.add(
					`giveaway.${interaction.message.id}.entered`,
					1,
				);

				const embed = EmbedBuilder.from(
					interaction.message.embeds[0],
				).setFields(
					{
						name: 'Ends',
						value: `${time(
							Math.round(data[0].endTime / 1000),
							'R',
						)}`,
						inline: true,
					},
					{
						name: 'Hosted by',
						value: `<@${data[0].hostedBy}>`,
						inline: true,
					},
				);
				const button = ActionRowBuilder.from(
					interaction.message.components[0],
				).setComponents(
					new ButtonBuilder()
						.setCustomId('giveaway')
						.setEmoji('🎉')
						.setLabel(`Entries - ${entries}`)
						.setStyle(ButtonStyle.Primary),
				);
				interaction.message.edit({
					embeds: [embed],
					components: [button],
				});
				interaction.reply({
					embeds: [
						new EmbedBuilder()
							.setColor('Green')
							.setDescription(
								`${
									client.emotes.tick
								} You are added to the ${hyperlink(
									'giveaway',
									data[0].url,
								)}`,
							),
					],
					ephemeral: true,
				});
			}
		}
		catch (e) {
			console.error(e);
		}
	},
};
