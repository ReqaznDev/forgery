const { EmbedBuilder, Events } = require('discord.js');

module.exports = {
	name: Events.InteractionCreate,
	once: false,
	async execute(interaction, client) {
		if (!interaction.isButton()) return;
		if (interaction.customId !== 'verifybutton') return;
		if (client.config.verifyRole) {
			interaction.member.roles.add(client.config.verifyRole);
		}
		const ezembed = new EmbedBuilder()
			.setColor('#4f47ff')
			.setDescription(
				'<:correct:1037826497551024128> | You have been **Verified**!',
			);
		interaction.reply({ embeds: [ezembed], ephemeral: true });
	},
};
