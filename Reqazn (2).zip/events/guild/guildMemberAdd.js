const { EmbedBuilder, Events } = require('discord.js');

module.exports = {
	name: Events.GuildMemberAdd,
	once: false,
	async execute(member, client) {
		let chnlId = client.db.get(`${member.guild.id}.welcome.channel`);
		let memlog = client.db.get(`${member.guild.id}.memberlog.channel`);

		if (chnlId) {
			const welcomechannel = await member.guild.channels.fetch(chnlId);
			if (!welcomechannel) return;

			let text = client.db.get(`${member.guild.id}.welcome.message`)
				? client.db.get(`${member.guild.id}.welcome.message`)
				: `Welcome to ${member.guild.name}`;

			const embed = new EmbedBuilder()
				.setAuthor({
					name: `${member.user.username}`,
					iconURL: member.user.avatarURL(),
				})
				.setColor('Random')
				.setDescription(
					`${text
						.replaceAll('{{guild}}', `${member.guild.name}`)
						.replaceAll('{{user}}', `${member.user.username}`)
						.replaceAll('{{userid}}', `${member.user.id}`)}`
				)
				.setFooter({
					text: `You're the ${member.guild.memberCount}th member`,
					iconURL: client.user.avatarURL(),
				});
			welcomechannel
				.send({ content: `${member}`, embeds: [embed] })
				.then((embedMessage) => {
					embedMessage.react('👋');
				});
		}
		if (memlog) {
			const logchan = await member.guild.channels.fetch(memlog);
			if (!logchan) return;

			const logembed = new EmbedBuilder()
				.setColor('Blurple')
				.setAuthor({
					name: `${member.user.username} (${member.user.id})`,
					iconURL: member.user.displayAvatarURL(),
				})
				.setTitle('__New User Joined__')
				.setDescription(
					`**Member:** \`${member.user.username}\` (${
						member.user.id
					}) \n **User Since:** <t:${parseInt(
						member.user.createdTimestamp / 1000
					)}:R> \n **Member Since:** <t:${parseInt(
						member.joinedTimestamp / 1000
					)}:R>`
				)
				.setTimestamp();
			logchan.send({ embeds: [logembed] });
		}
	},
};
