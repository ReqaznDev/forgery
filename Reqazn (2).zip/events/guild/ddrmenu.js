const { Events, EmbedBuilder } = require('discord.js');

module.exports = {
	name: Events.InteractionCreate,
	once: false,
	async execute(interaction, client) {
		// need customid check
	/*	if (!interaction.isStringSelectMenu()) return;
		const { guild } = interaction;

		const member = interaction.member;

		if (!client.config.auditlogChannel) return;
		const auditlogChannel = client.channels.cache.get(
			client.config.auditlogChannel,
		);
		const check = client.emotes.cache.get('1037826497551024128');
		const x = client.emotes.cache.get('1037826526781132861');

		const roleAdd = new EmbedBuilder()
			.setColor('#4f47ff')
			.setFooter({ text: `by ${guild.name}`, iconURL: guild.iconURL() });

		const nodmEmbed = new EmbedBuilder()
			.setTitle('DM\'s Closed!')
			.setDescription(
				`I could not DM ${member}, due to their DM's being closed.`,
			)
			.setColor('#4f47ff')
			.setFooter({
				text: `by ${client.user.username} ©2022`,
				iconURL: client.user.avatarURL(),
			});

		// EVENTS ROLE
		switch (interaction.values) {
		case 'voided':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('994437987347734597')) {
				await member.roles.add('994437987347734597');
				roleAdd.setDescription(
					`**${check} | \`Voided Host Updates\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('994437987347734597')) {
				await member.roles.remove('994437987347734597');
				roleAdd.setDescription(
					`**${x} | \`Voided Host Updates\` role removed successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}

			break;
			// POLLS
		case 'maintenance':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('994437987347734596')) {
				await member.roles.add('994437987347734596');
				roleAdd.setDescription(
					`**${check} | \`Maintenance\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('994437987347734596 ')) {
				await member.roles.remove('994437987347734596 ');
				roleAdd.setDescription(
					`**${x} | \`Maintenance\` role removed successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			break;

			// SPOTLIGHT ROLE
		case 'status':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('994437987347734595 ')) {
				await member.roles.add('994437987347734595 ');
				roleAdd.setDescription(
					`**${check} | \`Status Updates\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('994437987347734595 ')) {
				await member.roles.remove('994437987347734595 ');
				roleAdd.setDescription(
					`**${x} | \`Status Updates\` role removed successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			break;

			// CHATREVIVE ROLE

		case 'giveaways':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('994437987347734594')) {
				await member.roles.add('994437987347734594 ');
				roleAdd.setDescription(
					`**${check} | \`Giveaways\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('994437987347734594')) {
				await member.roles.remove('994437987347734594');
				roleAdd.setDescription(
					`**${x} | \`Giveaways\` role removed successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			break;

			// PARTNERSHIPS ROLE

		case 'offers':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('994437987347734593')) {
				await member.roles.add('994437987347734593');
				roleAdd.setDescription(
					`**${check} | \`Offers & Sales\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('994437987347734593')) {
				await member.roles.remove('994437987347734593');
				roleAdd.setDescription(
					`**${x} | \`Offers & Sales\` role removed successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			break;

			// BUMPERS ROLE

		case 'botupdates':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('1038600652655439932')) {
				await member.roles.add('1038600652655439932');
				roleAdd.setDescription(
					`**${check} | \`Bot Updates\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('1038600652655439932')) {
				await member.roles.remove('1038600652655439932');
				roleAdd.setDescription(
					`**${x} | \`Bot Updates\` role removed successfully!**`,
				);
				return interaction.member.send({ embeds: [roleAdd] });
			}
			break;

			// ANNOUNCEMENT ROLE
		case 'announcements':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('1038601302143418488')) {
				await member.roles.add('1038601302143418488');
				roleAdd.setDescription(
					`**${check} | \`Announcements\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('1038601302143418488')) {
				await member.roles.remove('1038601302143418488');
				roleAdd.setDescription(
					`**${x} | \`Announcements\` role removed successfully!**`,
				);
				return interaction.member.send({ embeds: [roleAdd] });
			}
			break;

			// WELCOMERS ROLE
		case 'tutorials':
			await interaction.deferUpdate();
			if (!member.roles.cache.has('994437987347734592')) {
				await member.roles.add('994437987347734592');
				roleAdd.setDescription(
					`**${check} | \`Tutorials\` role added successfully!**`,
				);
				try {
					return interaction.member.send({ embeds: [roleAdd] });
				}
				catch (error) {
					nodmEmbed.setTimestamp();
					return auditlogChannel.send({ embeds: [nodmEmbed] });
				}
			}
			else if (member.roles.cache.has('994437987347734592')) {
				await member.roles.remove('994437987347734592');
				roleAdd.setDescription(
					`**${x} | \`Tutorials\` role removed successfully!**`,
				);
				return interaction.member.send({ embeds: [roleAdd] });
			}
			break;
		default:
			break;
		} */
	},
};
