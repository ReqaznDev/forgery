const { EmbedBuilder, Events } = require('discord.js');

module.exports = {
	name: Events.GuildMemberRemove,
	once: false,
	async execute(member, client) {
		let chnlId = client.db.get(`${member.guild.id}.leave.channel`);
		let memlog = client.db.get(`${member.guild.id}.memberlog.channel`);

		if (chnlId) {
			const leaveChannel = await member.guild.channels.fetch(chnlId);
			if (!leaveChannel) return;

			let text = client.db.get(`${member.guild.id}.leave.message`)
				? client.db.get(`${member.guild.id}.leave.message`)
				: `User Left {{user}}`;

			const embed = new EmbedBuilder()
				.setAuthor({
					name: `${member.user.username}`,
					iconURL: member.user.avatarURL(),
				})
				.setColor('Random')
				.setDescription(
					`${text
						.replaceAll('{{guild}}', `${member.guild.name}`)
						.replaceAll('{{user}}', `${member.user.username}`)
						.replaceAll('{{userid}}', `${member.user.id}`)}`
				)
				.setFooter({
					text: `Now got ${member.guild.memberCount} members`,
					iconURL: client.user.avatarURL(),
				});
			leaveChannel.send({ embeds: [embed] }).then((embedMessage) => {
				embedMessage.react('👋');
			});
		}
		if (memlog) {
			const logchan = await member.guild.channels.fetch(memlog);
			if (!logchan) return;

			const logembed = new EmbedBuilder()
				.setColor('Blurple')
				.setAuthor({
					name: `${member.user.username} (${member.user.id})`,
					iconURL: member.user.displayAvatarURL(),
				})
				.setTitle('__User Left__')
				.setDescription(
					`**Member:** \`${member.user.username}\` (${
						member.user.id
					}) \n **User Since:** <t:${parseInt(
						member.user.createdTimestamp / 1000
					)}:R> \n **Member Since:** <t:${parseInt(
						member.joinedTimestamp / 1000
					)}:R>`
				)
				.setTimestamp();
			logchan.send({ embeds: [logembed] });
		}
	},
};
