const { Events, EmbedBuilder, time } = require('discord.js');
const ms = require('ms');

module.exports = {
	name: Events.ClientReady,
	once: false,
	async execute(client) {
		setInterval(async () => {
			const guilds = client.db.all();
			for (const value of guilds) {
				if (Object.hasOwn(value.data, 'moderations')) {
					const x = value.data.moderations;
					const guildId = value.ID;
					const guild = client.guilds.cache.get(guildId);
					x.forEach(async (data) => {
						if (!data.duration || isNaN(data.duration)) return;
						if (data.action.toLowerCase() !== 'warn') return;

						if (Date.now() > data.duration) {
							const member = await guild.members.fetch(
								data.member,
							);
							client.db.pull(
								`${guildId}.moderations`,
								(element) => element.caseId === data.caseId,
								true,
							);

							const logChannelId =
								client.config.logChannel ||
								client.db.get(
									`${guild.id}.config.logChannel`,
								) ||
								'926824838134399026';

							const logChannel = await guild.channels.fetch(
								logChannelId,
							);

							const count =
								client.db
									.get(`${guild.id}.moderations`)
									.filter(
										(a) =>
											a.member == member.id &&
											a.action.toLowerCase() == 'warn',
									)?.length || 0;

							const embed = new EmbedBuilder()
								.setAuthor({
									name: member.user.username,
									iconURL: member.displayAvatarURL(),
								})
								.setTitle('User Automatically unwarned')
								.setDescription(
									`\`👤\` Successfully unwarned ${member}\`(${member.id})\` `,
								)
								.addFields(
									{
										name: '`🔨` Reason',
										value: data.reason,
										inline: true,
									},
									{
										name: '`👤` Moderator',
										value: `<@${data.mod}> \`(${data.mod})\``,
										inline: true,
									},
									{
										name: '`⌛` Duration',
										value: `${ms(
											data.duration - data.time,
											{
												long: true,
											},
										)}`,
										inline: true,
									},
								)
								.setTimestamp()
								.setColor('Red')
								.setFooter({
									text: `${guild.name} | Case ID: ${data.caseId}`,
									iconURL: guild.iconURL(),
								});

							const dmEmbed = new EmbedBuilder()
								.setAuthor({
									name: guild.name,
									iconURL: guild.iconURL(),
								})
								.addFields(
									{
										name: '`🔨` Warning Reason',
										value: data.reason,
										inline: true,
									},
									{
										name: '`📥` Server',
										value: guild.name,
										inline: true,
									},
								)
								.setTimestamp()
								.setColor('Red')
								.setTitle('Warning Expired')
								.setDescription(
									`A warning issued ${
										data.time
											? time(
												Math.round(
													data.time / 1000,
												),
												'R',
											  )
											: 'a while ago'
									}, was automatically removed due to expiring. You now have **${count} warnings**.`,
								)
								.setColor('#7E51B7')
								.setFooter({
									text: `Case ID: ${data.caseId}`,
								});

							try {
								await member.send({
									content: `<@${member.id}>`,
									embeds: [dmEmbed],
								});
								embed.addFields({
									name: '`✅` Member Notified',
									value: 'True!',
									inline: true,
								});
							}
							catch {
								embed.addFields({
									name: '`✅` Member Notified',
									value: 'False',
									inline: true,
								});
							}

							logChannel.send({ embeds: [embed] });
						}
					});
				}
			}
		}, 5000);
	},
};
