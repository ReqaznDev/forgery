const status = require('../../status.json');
const { Events, ActivityType } = require('discord.js');

module.exports = {
	name: Events.ClientReady,
	once: false,
	async execute(client) {
		console.log(`Logged in as ${client.user.username}`);
		client.user.setActivity(status.status, {
			name: status.status,
			type: ActivityType.Streaming,
			url: 'https://www.twitch.tv/ReqaznTheDev',
		});
	},
};
