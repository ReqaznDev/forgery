const { Events } = require('discord.js');

module.exports = {
	name: Events.ClientReady,
	once: false,
	async execute(client) {
		const db = client.db;
		setInterval(async () => {
			let breaks = db.get('breaks');
			for (let i in breaks) {
				const time = breaks[i].time;
				const guildId = breaks[i].guild;
				const guild = client.guilds.cache.get(guildId);
				await guild.members.fetch();
				let member = guild.members.cache.get(i);
				if (member) {
					if (Date.now() > time) {
						const guildMember = await guild.members.fetch(i);
						if (guildMember) {
							await db.delete(`breaks.${i}`);
						}

						const rrdata2 = client.db.get(
							`${guildId}.break.role`
						);

						guildMember.roles
							.remove(rrdata2)
							.catch((err) =>
								console.log(
									`Couldn't Add Role to User on Staff server\n${member.id}\n--------------------------\n${err}`
								)
							);
						member
							.send(
								'Your break time is up, You can get back to work'
							)
							.catch((err) =>
								console.log(
									`Users DMS Are Closed\nUser: ${member.id}\n--------------------------\n${err}`
								)
							);

						await db.delete(`breaks.${i}`);

						console.log(`I have removed ${member.id} from break.`);
					}
				} else {
					await db.delete(`breaks.${i}`);

					console.log(
						`Couldn't Find ${i}, But i have removed them from the break`
					);
				}
			}
		}, 5000);
	},
};
