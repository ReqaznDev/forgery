**OKi Helu!**

You need to some config in order to run this bot

You will need your 
- bot token
- bot id
- the guild id of where the commands that are not global are to be accessed on
- a private guild's id (Doesn't have to be private, the bot just needs to be in the server) to upload the emojis
- a bunch of channel and role ids

**Oki Lets Start Setting up! ** 

- **__Bot Token__**
> see the example.env?
> ```token=<token>```
> Replace `<token>` with your *bot token*
> once you do that, rename `example.env` to  just `.env`

- __**Config File**__
> open config.js
> and replace the details accordingly, ig u can figure this out urself :P
> *ask if u need help*

- **__Emoji upload__**
> Once all these settings are setup
> Open up your terminal in the root directory and run `node emoji <private_guildId>`
> Replace `<private_guildId>` with the guild id where you wish to upload the emojis
> 
> **Example**: I need to upload the emojis to the guild with id - `771654151733248010`
> so i run `node emoji 771654151733248010`
> 
> **__NOTE:  The bot must have access to the guild mentioned__**

- **__Change Status__**
> Open `status.json` and replace the content in `status` to your likings

- __**Done!**__
> Now run `npm i`
> YOu can start the bot now :)